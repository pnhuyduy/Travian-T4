<?php
	//gp link
	if($session->gpack == null || GP_ENABLE == false) {
	$gpack= GP_LOCATE;
	} else {
	$gpack= $session->gpack;
	}


//de bird
if($displayarray['protect'] > time()){
$uurover=date('H:i:s', ($displayarray['protect'] - time()));
$profiel = preg_replace("/\[#0]/is",'<img src="'.$gpack.'img/t/tn.gif" border="0" title="'.sprintf(UBPUNTIL,$uurover).'" >', $profiel, 1);
} else {
$geregistreerd=date('Y/m/d', ($displayarray['timestamp']));
$tregistreerd=date('H:i', ($displayarray['timestamp']));
$profiel = preg_replace("/\[#0]/is",'<img src="'.$gpack.'img/t/tnd.gif" border="0" title="'.sprintf(PLAYERREGAT,$geregistreerd.' '.$tregistreerd).'">', $profiel, 1);
}

//natar image
if($displayarray['username'] == "Natars"){
$profiel = preg_replace("/\[#natars]/is",'<img src="'.$gpack.'img/t/t10_2.jpg" border="0">', $profiel, 1);
$profiel = preg_replace("/\[#natars]/is",'<img src="'.$gpack.'img/t/t10_2.jpg" border="0">', $profiel, 1);
}

//de lintjes
/******************************
INDELING CATEGORIEEN:
===============================
== 1. Attackers top 10       ==
== 2. Defence top 10         ==
== 3. Climbers top 10        ==
== 4. Raiders top 10 	     ==
== 5. attackers and defences ==
== 6. in top 3 - Attackers   ==
== 7. in top 3 - Defence 	 ==
== 8. in top 3 - Climbers    ==
== 9. in top 3 - Raiders     ==
******************************/

foreach($varmedal as $medal) {

switch ($medal['categorie']) {
    case "1":
        $titel=PF_MD1;
		$woord=AL_POINTS;
        break;
    case "2":
        $titel=PF_MD2;
 		$woord=AL_POINTS;
       break;
    case "3":
        $titel=PF_MD3;
 		$woord=AL_POINTS;
       break;
    case "4":
        $titel=PF_MD4;
		$woord=AL_POINTS;
        break;
	 case "5":
        $titel=AL_POINTS;
        $bonus[$medal['id']]=1;
		break;
	 case "6":
        $titel=sprintf(PF_MD5,$medal['points']);
        $bonus[$medal['id']]=1;
		break;
	 case "7":
        $titel=sprintf(PF_MD6,$medal['points']);
        $bonus[$medal['id']]=1;
		break;
	 case "8":
        $titel=sprintf(PF_MD7,$medal['points']);
        $bonus[$medal['id']]=1;
		break;
	 case "9":
        $titel=sprintf(PF_MD8,$medal['points']);
        $bonus[$medal['id']]=1;
		break;
     case "10":
        $titel=PF_MD3;
        $woord=AL_RANK;
        break;
         case "11":
        $titel=sprintf(PF_MD7,$medal['points']);
        $bonus[$medal['id']]=1;
        break;
         case "12":
        $titel=sprintf(PF_TOP10AOFW,$medal['points']);
        $bonus[$medal['id']]=1;
        break;
        case "13":
        $titel=sprintf(PF_TOP10DOFW,$medal['points']);
        $bonus[$medal['id']]=1;
        break;
        case "14":
        $titel=sprintf(PF_TOP10COFW,$medal['points']);
        $bonus[$medal['id']]=1;
        break;
        case "15":
        $titel=sprintf(PF_TOP10ROFW,$medal['points']);
        $bonus[$medal['id']]=1;
        break;
        case "16":
        $titel=sprintf(PF_TOP10COFW,$medal['points']);
        $bonus[$medal['id']]=1;
        break;
        

}

if(isset($bonus[$medal['id']])){

	$profiel = preg_replace("/\[#".$medal['id']."]/is",'<img class="medal '.$medal['img'].'" src="img/x.gif" title="'.$titel.'<br />'.AL_WEEK.' '.$medal['week'].'">', $profiel, 1);
} else {
	$profiel = preg_replace("/\[#".$medal['id']."]/is",'<img class="medal '.$medal['img'].'" src="img/x.gif" title="'.AL_CATEGORY.': '.$titel.'<br />'.AL_WEEK.': '.$medal['week'].'<br />'.AL_RANK.': '.$medal['plaats'].'<br />'.$woord.': '.$medal['points'].'<br />">', $profiel, 1);
}
}


$ref = mysql_query("SELECT `email` FROM ".TB_PREFIX."users where id = ".$_GET['uid'])or die(mysql_error());
$row = mysql_fetch_assoc($ref);

$dbs = mysql_connect('localhost',$AppConfig['md']['user'],$AppConfig['md']['password']);
mysql_select_db($AppConfig['md']['database'], $dbs);


function getMedal($uid)
{
	$q = "SELECT * from medal where email = '".$uid."' order by id desc";
	$result = mysql_query($q);
	while($row = mysql_fetch_assoc($result)){
		$array[] = $row;
	}
	return $array;
}

$vars = getMedal($row['email']);

$winn_counter = 0;

//print_r($vars);
?>
<style>
img.winner_tw_1{background-image:url(<?php echo GP_LOCATE;?>/img/t/red.png);width:113px;height:156px;}
img.winner_tw_2{background-image:url(<?php echo GP_LOCATE;?>/img/t/blue.png);width:113px;height:156px;}
img.winner_tw_3{background-image:url(<?php echo GP_LOCATE;?>/img/t/green.png);width:113px;height:156px;}
</style>
<?php
foreach($vars as $var) {

	switch ($var['categorie']) {
		case 'winner':
			$_{$var['status']}++;
			break;
	}

}
foreach($vars as $var) {
	switch ($var['categorie']) {
		case 'winner':
			$titelm='Winner Server '.$var['status'].' For '.$_{$var['status']}.' Times';
			$profiel = preg_replace("/\[#".$var['status']."]/is",'<img class="winner_'.$var['img'].'_'.($var['status'] == 'tx500' ? '1' : ($var['status'] == 'tx1000' ? '2' : '3') ).'" src="img/x.gif" title="'.$titelm.'">', $profiel, 1);
			break;
	}
}


mysql_close($dbs);
mysql_connect(SQL_SERVER, SQL_USER, SQL_PASS);
mysql_select_db(SQL_DB);
?>

